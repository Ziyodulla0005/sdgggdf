
import React from "react";
import Main from "./Main";
import Main2 from './Main2';
import M from './M';
import {BrowserRouter as Router,Route,Routes ,Link} from"react-router-dom"
import Idea from "./Idea";
import Test from "./Test";
import TestResult from "./TestResult"
function App() {

  return (
    <div className="App">
     <Router>
       <Routes>
         <Route path="/" exact element={<Main/>}/>
         <Route path="/main/:id"  element={<Main2/>}/>
         <Route path="idea"  element={<Idea/>}/>
         <Route path="test" element={<Test/>}/>
         <Route path="testr" element={<TestResult/>}/>
       </Routes>
       </Router> 
       


    </div>
  );
}

export default App;
