import Axios from "axios";

// import { Button } from 'react-bootstrap';
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Test() {
  const [data, setDate] = useState([]);
  const [savol, setSavol] = useState("");
  // const [editId,setEditId]=useState()
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [c, setC] = useState("");

  const [d, setD] = useState("");
 


  useEffect(() => {
    Axios.get(
      "https://62df7e489c47ff309e86eacb.mockapi.io/test"
    )
      .then((res) => {
        console.log("Getting from ::::", res.data);
        setDate(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  const postData = (e) => {
   
      e.preventDefault();
      Axios.post(
        "https://62df7e489c47ff309e86eacb.mockapi.io/test",
        {
          savol,
          a,
          b,
          c,
          d,
          
        },
        setSavol(""),
        setA(""),
        setB(""),
        setC(""),
        setD(""),
        
      )
        .then((res) => console.log("Posting data", res))
        .catch((err) => console.log(err));
      
    }
  
  
  return (
    <div className="App">
    
     

      <div className="login-page">
       
        {/* axa */}
        <div class="wrapper">
          <h2>Registration</h2>
          <form>
            <div class="input-box">
              <input
                type="text"
                placeholder="Enter your name"
                required
                value={savol}
                onChange={(e) => setSavol(e.target.value)}
              />
            </div>
            <div class="input-box">
              <input
                type="string"
                
                required
                value={a}
                onChange={(e) => setA(e.target.value)}
              />
            </div>
            <div class="input-box">
              <input
                type="string"
               
                value={b}
                onChange={(e) => setB(e.target.value)}
              />
            </div>
            <div class="input-box">
              <input
                type="string"
               
                required
                value={c}
                onChange={(e) => setC(e.target.value)}
              />
            </div>
            <div class="input-box">
              <input
                type="string"
               
                required
                value={d}
                onChange={(e) => setD(e.target.value)}
              />
            </div>
            <div class="input-box">
                select true answer
            <select class="form-select" aria-label="Default select example">
  <option selected>A</option>
  <option value="1">B</option>
  <option value="2">C</option>
  <option value="3">D</option>
</select>
            </div>
            <div class="input-box button">
              <input type="Submit" value="Add" onClick={postData} />
            </div>
       
          </form>
        </div>
        <Link to='/'><button >userlar malumotlarini korish</button></Link>
        <Link to='/idea'><button >Fikrlarni korish</button></Link>
      </div>

      {/* <table style={{border:'1px solid black'}}>
  <tr>
    <th style={{border:'1px solid black'}}>ID</th>
    <th style={{border:'1px solid black'}}>name</th>
    <th style={{border:'1px solid black'}}>surname</th>
    <th style={{border:'1px solid black'}}>age</th>
    <th style={{border:'1px solid black'}}>email</th>
    <th style={{border:'1px solid black'}}>tel</th>
    <th style={{border:'1px solid black'}}>passvord</th>
    <th style={{border:'1px solid black'}}>update</th>
    <th style={{border:'1px solid black'}}>delete</th>
  </tr>
  {arr}
</table> */}
      {/* {!! editId && <Main2 name={editId} key={editId


} initialName={data.user} initialAge={data.age} initialEmail={data.email} 
initialSurNAme={data.surName} initialTele={data.tele} initialPassvord={data.passvord}/>} */}
    </div>
  );
}

export default Test;
