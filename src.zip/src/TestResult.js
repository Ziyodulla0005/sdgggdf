import  Axios  from 'axios';
import React,{ useEffect, useState } from 'react';
import{Container,Col,Row,Card,CardGroup}from 'react-bootstrap'
function TestResult() {
  const[data,setDate]=useState([])
  const [savol,setSavol]=useState('')
 
  const [b,setB]=useState('')
  const [a, setA] =useState('')
  const [c, setC] =useState('')

  const [d, setD] = useState('')




  useEffect(()=>{
    Axios.get('https://62df7e489c47ff309e86eacb.mockapi.io/test')
    .then(res=>{
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])

  const postData=(e)=>{
    e.preventDefault();
    Axios.post('https://62df7e489c47ff309e86eacb.mockapi.io/test',{
      savol,
      a,
      b,
      c,
      d
     
    }).then(res=>console.log('Posting data',res)).catch(err => console.log(err))
  }
  const postDelete=(id,e)=>{
    e.preventDefault();
    Axios.delete(`https://62df7e489c47ff309e86eacb.mockapi.io/test/${id}`)
    .then(res=>console.log('Deleting!!!',res)).catch(err => console.log(err))
  }
  
//   const arr =data.map((data,index)=>{
//     return(
      
      
      
//       <tr>
//         <td style={{border:"1px solid black"}}>{data.id}</td>
//         <td style={{border:"1px solid black"}}>{data.user}</td>
//         <td style={{border:"1px solid black"}}>{data.surName}</td>
//         <td style={{border:"1px solid black"}}>{data.age}</td>
//         <td style={{border:"1px solid black"}}>{data.email}</td>
//         <td style={{border:"1px solid black"}}>{data.tele}</td>
//         <td style={{border:"1px solid black"}}>{data.passvord}</td>
        
//         <td style={{border:"1px solid black"}}><button onClick={()=>{
//             //setEditId(data.id);
//              onClick(data.id);
//              }}>update</button></td>
//         <td style={{border:"1px solid black"}}><button onClick={(e)=>{postDelete(data.id,e);
//         }}>delete</button></td>
//       </tr>
//     )
//   })
const arr =data.map((data)=>{
    return(
<Row >
    <Col>
    <CardGroup>
    <Card  style={{ width: '50px' ,marginTop:'10px'}}>
        <form>
        <label>{data.id} </label>
        <input value={data.savol} />
        <hr/>
        <label>{data.a}</label>
        <input  type="radio" value={data.a} />
        <hr/>
        <label>{data.b}</label>
        <input type="radio"  value={data.b} />
        <hr/>
        <label>{data.c}</label>
        <input type="radio" value={data.c} />
        <hr/>
        <label>{data.d}</label>
        <input type="radio" value={data.d} />
        <hr/>
   


      </form> </Card></CardGroup>
    </Col>
</Row>
    
)})
  return (
    <Container>
    <div className="App1" >
      <h1>test</h1>
      <Row  xs={1} md={2} className="g-4">
      
       {arr}
</Row>

    </div></Container>
  );
}

export default TestResult;
