import React,{useEffect, useState} from 'react';
import Axios from 'axios';
import{useNavigate, useParams} from "react-router-dom"

function Main2({initialUser, initialAge,initialEmail,initialTele,initialPassvord,initialSurName}){
    const [user, setUser] = React.useState(initialUser)
    const { itemId } = useParams()
    const [loading, setLoading] = useState(false);
    const [surName, setSurName] = React.useState(initialSurName)
    const [age, setAge] = React.useState(initialAge)
    const [email, setEmail] = React.useState(initialEmail)
    const [tele, setTele] = React.useState(initialTele)
    const [passvord, setPassvord] = React.useState(initialPassvord)
    const navigate=  useNavigate();
    const {id} = useParams();

    useEffect(()=>{
        setLoading(true);
        Axios.get(`https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya/${id}`)
        .then(res=>{
          console.log("Getting from ::::",res.data)
          const { data } = res;
        setSurName(data.surName)
        setUser(data.user)
        setAge(data.age)
        setEmail(data.email)
        setTele(data.tele)
        setPassvord(data.passvord)
        setLoading(false)
        }).catch(err => console.log(err)) 
      },[])

    const postData = (e)=>{
        e.preventDefault();
        Axios.put(`https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya/${id}`, {user,surName, age,email,tele,passvord})
        .then(res => {
            navigate("/") 
            console.log('Deleting!!!',res)
        }).catch(err => console.log(err))
    }
    
    useEffect(()=>{
        setUser(localStorage.getItem('user'));
        setSurName(localStorage.getItem('surName'));
        setAge(localStorage.getItem('age'));
        setEmail(localStorage.getItem('email'));
        setTele(localStorage.getItem('tele'));
        setPassvord(localStorage.getItem('passvord'));
    },[])
   
    return (
        <>{loading ? <h1>loading...</h1> : 
        <div>
        <p>Edit {itemId}-user</p>
           <form>
        <label>name</label>
        <input type="text" value={user} onChange={(e)=>setUser(e.target.value)}/>
        <hr/>
        <label>surname</label>
        <input type="text" value={surName} onChange={(e)=>setSurName(e.target.value)}/>
        <hr/>
        <label>age</label>
        <input type="number" value={age} onChange={(e)=>setAge(e.target.value)}/>
        <hr/>
        <label>email</label>
        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <hr/>
        <label>tel</label>
        <input type="number" value={tele} onChange={(e)=>setTele(e.target.value)}/>
        <hr/>
        <label>emaildf</label>
        <input type="password" value={passvord} onChange={(e)=>setPassvord(e.target.value)}/>
        <hr/>
<button onClick ={(e)=>{
    // onClick(e.id);
    postData(e);} }>Post</button>

      </form>
    </div>}</>
    );
}
export default Main2