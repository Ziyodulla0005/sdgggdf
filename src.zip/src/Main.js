import  Axios  from 'axios';
import React,{ useEffect, useState } from 'react';
import{useNavigate ,Link} from "react-router-dom"
import Main2 from './Main2';
function Main() {
  const[data,setDate]=useState([])
  const [user,setUser]=useState('')
  const [editId,setEditId]=useState()
  const [email,setEmail]=useState('')
  const [surName, setSurName] =useState('')
  const [age, setAge] =useState('')

  const [tele, setTele] = useState('')
  const [passvord, setPassvord] = useState('')
  

const navigate=useNavigate()
const onClick=(id)=>{
setTimeout(() => {
    navigate("main/"+id)
}, 100);
}
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya')
    .then(res=>{
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])

  const postData=(e)=>{
    e.preventDefault();
    Axios.post('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya',{
      user,
      surName,
      age,
      email,
      tele,
      passvord
    }).then(res=>console.log('Posting data',res)).catch(err => console.log(err))
  }
  const postDelete=(id,e)=>{
    e.preventDefault();
    Axios.delete(`https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya/${id}`)
    .then(res=>console.log('Deleting!!!',res)).catch(err => console.log(err))
  }
  
  const arr =data.map((data,index)=>{
    return(
      <tr>
        <td style={{border:"1px solid black"}}>{data.id}</td>
        <td style={{border:"1px solid black"}}>{data.user}</td>
        <td style={{border:"1px solid black"}}>{data.surName}</td>
        <td style={{border:"1px solid black"}}>{data.age}</td>
        <td style={{border:"1px solid black"}}>{data.email}</td>
        <td style={{border:"1px solid black"}}>{data.tele}</td>
        <td style={{border:"1px solid black"}}>{data.passvord}</td>
        
        <td style={{border:"1px solid black"}}><button onClick={()=>{
            //setEditId(data.id);
             onClick(data.id);
             }}>update</button></td>
        <td style={{border:"1px solid black"}}><button onClick={(e)=>{postDelete(data.id,e);
        }}>delete</button></td>
      </tr>
    )
  })
  return (
    <div className="App1" style={{width:'100%'}}>
{/*       
      <form>
      <label>name</label>
        <input type="text" value={user} onChange={(e)=>setUser(e.target.value)}/>
        <hr/>
        <label>surname</label>
        <input type="text" value={surName} onChange={(e)=>setSurName(e.target.value)}/>
        <hr/>
        <label>age</label>
        <input type="number" value={age} onChange={(e)=>setAge(e.target.value)}/>
        <hr/>
        <label>email</label>
        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <hr/>
        <label>tel</label>
        <input type="number" value={tele} onChange={(e)=>setTele(e.target.value)}/>
        <hr/>
        <label>emaildf</label>
        <input type="passvord" value={passvord} onChange={(e)=>setPassvord(e.target.value)}/>
        <hr/>
<button onClick={postData}>Post</button>

      </form> */}
<table style={{border:'1px solid black'}}>
  <tr>
    <th style={{border:'1px solid black'}}>ID</th>
    <th style={{border:'1px solid black'}}>name</th>
    <th style={{border:'1px solid black'}}>surname</th>
    <th style={{border:'1px solid black'}}>age</th>
    <th style={{border:'1px solid black'}}>email</th>
    <th style={{border:'1px solid black'}}>tel</th>
    <th style={{border:'1px solid black'}}>passvord</th>
    <th style={{border:'1px solid black'}}>update</th>
    <th style={{border:'1px solid black'}}>delete</th>
  </tr>
  {arr}
</table>
<Link to='/idea'><button >Fikrlarni korish</button></Link>
<Link to='/test'><button >Test qoshish</button></Link>
{!! editId && <Main2 name={editId} key={editId} initialName={data.user} initialAge={data.age} initialEmail={data.email} 
initialSurNAme={data.surName} initialTele={data.tele} initialPassvord={data.passvord}/>}

    </div>
  );
}

export default Main;
