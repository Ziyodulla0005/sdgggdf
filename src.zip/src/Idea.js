import  Axios  from 'axios';
import React,{ useEffect, useState } from 'react';
import{Link} from "react-router-dom"
import Main2 from './Main2';
function Idea(){
  const[data,setDate]=useState([])
  const [name,setName]=useState('')
  const [editId,setEditId]=useState()
  const [email,setEmail]=useState('')
  const [surname, setSurname] =useState('')
 

  const [tele, setTele] = useState('')
  const [text, setText] = useState('')
  

// const navigate=useNavigate()
// const onClick=(id)=>{
// setTimeout(() => {
//     navigate("main/"+id)
// }, 100);
// }
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/Contakt')
    .then(res=>{
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])

  const postData=(e)=>{
    e.preventDefault();
    Axios.post('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/Contakt',{
      name,
      surname,
      
      email,
      tele,
      text
    }).then(res=>console.log('Posting data',res)).catch(err => console.log(err))
  }
  const postDelete=(id,e)=>{
    e.preventDefault();
    Axios.delete(`https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/Contakt/${id}`)
    .then(res=>console.log('Deleting!!!',res)).catch(err => console.log(err))
  }
  
  const arr =data.map((data,index)=>{
    return(
      <tr>
        <td style={{border:"1px solid black"}}>{data.id}</td>
        <td style={{border:"1px solid black"}}>{data.name}</td>
        <td style={{border:"1px solid black"}}>{data.surname}</td>
        
        <td style={{border:"1px solid black"}}>{data.email}</td>
        <td style={{border:"1px solid black"}}>{data.tele}</td>
        <td style={{border:"1px solid black"}}>{data.text}</td>
        
        {/* <td style={{border:"1px solid black"}}><button onClick={()=>{
            //setEditId(data.id);
             onClick(data.id);
             }}>update</button></td> */}
        <td style={{border:"1px solid black"}}><button onClick={(e)=>{postDelete(data.id,e);
        }}>delete</button></td>
      </tr>
    )
  })
  return (
    <div className="App1" style={{width:'100%'}}>
{/*       
      <form>
      <label>name</label>
        <input type="text" value={user} onChange={(e)=>setUser(e.target.value)}/>
        <hr/>
        <label>surname</label>
        <input type="text" value={surName} onChange={(e)=>setSurName(e.target.value)}/>
        <hr/>
        <label>age</label>
        <input type="number" value={age} onChange={(e)=>setAge(e.target.value)}/>
        <hr/>
        <label>email</label>
        <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <hr/>
        <label>tel</label>
        <input type="number" value={tele} onChange={(e)=>setTele(e.target.value)}/>
        <hr/>
        <label>emaildf</label>
        <input type="passvord" value={passvord} onChange={(e)=>setPassvord(e.target.value)}/>
        <hr/>
<button onClick={postData}>Post</button>

      </form> */}
<table style={{border:'1px solid black'}}>
  <tr>
    <th style={{border:'1px solid black'}}>ID</th>
    <th style={{border:'1px solid black'}}>name</th>
    <th style={{border:'1px solid black'}}>surname</th>

    <th style={{border:'1px solid black'}}>email</th>
    <th style={{border:'1px solid black'}}>tel</th>
    <th style={{border:'1px solid black'}}>text</th>
 
    <th style={{border:'1px solid black'}}>delete</th>
  </tr>
  {arr}
</table>
{/* {!! editId && <Main2 name={editId} key={editId


} initialName={data.user} initialAge={data.age} initialEmail={data.email} 
initialSurNAme={data.surName} initialTele={data.tele} initialText={data.passvord}/>} */}
<Link to='/'><button >userlar malumotlarini korish</button></Link>
<Link to='/test'><button >Test qoshish</button></Link>
    </div>
  );
}

export default Idea;
