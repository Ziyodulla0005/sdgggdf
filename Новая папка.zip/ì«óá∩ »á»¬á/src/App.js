import './App.css';
import Nav from './nav/Nav'
import React  from 'react';
import {Routes,Route} from 'react-router-dom'
import SignUp from './componnents/SignUp';
import LogIn from './componnents/LogIn'
import Contact from './componnents/Contact'
import Home from './componnents/Home'
import Personal from './componnents/Personal';
import Footer from './componnents/Footer';
import PersonalInformation from './componnents/PersonalInformation'
function App() {
  return (
    <div className="App">
      {/* <Nav/> */}
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/contact'  element={<Contact/>}/>
        <Route path='/login'  element={<LogIn/>}/>
        <Route path='/signup'  element={<SignUp/>}/>
        <Route path='/login/personal/:id' element={<Personal/>}/>
       
      </Routes>
      <Footer/>
    </div>
  );
}


export default App;
