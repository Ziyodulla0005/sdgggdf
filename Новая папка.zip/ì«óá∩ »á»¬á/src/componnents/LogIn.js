import React,{useState,useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Axios from 'axios'
import Nav from '../nav/Nav';
import './Login.css';
import Personal from './Personal';
export default function LogIn() {
  const[userCheck, setUserCheck]= useState('')
  const[paswordCheck, setPaswordCheck]= useState('')
  const[data,setDate]=useState([])
  const[javob,setJavob]=useState("1")
  const[javob1,setJavob1]=useState("2")
  const[javob2,setJavob2]=useState("3")
  const[javob3,setJavob3]=useState("4")
  const [editId,setEditId]=useState()
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya')
    .then(res=>{
     // malumot.push(res.data)
    
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])
 const navigate = useNavigate()
  const Check = (e)=>{
    for (let i = 0; i < e.length; i++) {
      const element = e[i];
       if (element.user === userCheck) {
          setJavob("usertogri")
        if (element.passvord === paswordCheck) {
         
          // navigate("/personal")
          
            navigate("personal/"+element.id)
    
        }else{
             setJavob2("kengi pejga otish")
        }
       }else{
        if (javob === "1") {
         
          setJavob3("xato")
        }
       
      }
    }
   
  
     
  }

  return (
    
<div>
<Nav/>
<div className="container">
<div className="screen">
  <div className="screen__content">
    <form className="login">
      <div className="login__field">
        <i className="login__icon fas fa-user"></i>
        <input type="text" className="login__input" placeholder="User name / Email" required value={userCheck} onChange={(e)=>setUserCheck(e.target.value)}/>
      </div>
      <div className="login__field">
        <i className="login__icon fas fa-lock"></i>
        <input type="password" className="login__input" placeholder="Password" required onChange={(e)=>setPaswordCheck(e.target.value)}/>
      </div>


      
      <button className="button login__submit"
        onClick={e=>{ 
         Check(data)
         }} 
         type="Submit" value="kirish">
        <span className="button__text">Log In Now</span>
        <i className="button__icon fas fa-chevron-right"></i>
      </button>        
    </form>

    <div className="social-login">
      <h3>{javob3}</h3>
      <div className="social-icons">
        <a href="#" className="social-login__icon fab fa-instagram"></a>
        <a href="#" className="social-login__icon fab fa-facebook"></a>
        <a href="#" className="social-login__icon fab fa-twitter"></a>
      </div>
    </div>
  </div>
  <div className="screen__background">
    <span className="screen__background__shape screen__background__shape4"></span>
    <span className="screen__background__shape screen__background__shape3"></span>    
    <span className="screen__background__shape screen__background__shape2"></span>
    <span className="screen__background__shape screen__background__shape1"></span>
  </div>    
</div>
</div></div>

  )
}
