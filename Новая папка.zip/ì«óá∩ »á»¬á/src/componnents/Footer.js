import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import { Telephone, GeoAlt, Envelope, Apple } from "react-bootstrap-icons";
import  ReactDOM from "react";
import { Link } from "react-router-dom";
import "./footer.css"

export default function Footer() {
 
  return (
    <div className="footer">
      
      <h2 className="logo">
        
        <br></br><br></br>
        
      </h2>
      <Container>
        <Row>
          <Col>
            <ul>
            <Link to="/"> <h2 className="logo">
        Onlayn <span className="test">test</span>
      </h2></Link>
              <div></div>
              <div >
                <Apple /> App store
              </div>
            </ul>
          </Col>
          <Col>
            <ul className="q">
              <h3 >Aloqa malumotlari</h3>
              <div>
                <Telephone />  <a href="tel:+998900031506">
                90 003 15 60<br/></a>
                <Telephone /> 
                
              <a href="tel:+998997668334">
                99 766 83 34</a>
              </div>
              <div>
                <Envelope />
              
                  ziyodullalutfullayev15@gmail.com
                
                
              </div>
              <div>
                <GeoAlt />
                Toshkent shahar Yakkasaroy tumani
              </div>
            </ul>
          </Col>
          <Col>
            <ul>
              <h3>Ishonch telfoni</h3>
              <a href="tel:+998900031506">
                 <div>+998 90 003 15 60</div>
              </a>
             
              <a href="tel:+998997668334">
                 <div>+998 99 766 83 34</div>
              </a>
         
              <Link to="contact">
                
                <div>Savol va taklif yo'llash</div>
              </Link>
            </ul>
          </Col>
        </Row>
      </Container>
      {/* </Container> */}
    </div>
  );
}
