import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./sihnup.css";
import Axios from "axios";
import Nav from "../nav/Nav";
export default function Contact() {
  // import{useNavigate} from "react-router-dom"
  // import Main2 from './Main2';

  const [data, setDate] = useState([]);
  const [name, setName] = useState("");
  // const [editId,setEditId]=useState()
  const [email, setEmail] = useState("");
  const [surname, setSurname] = useState("");

  const [text, setText] = useState("");

  const [tele, setTele] = useState("");

  // const navigate=useNavigate()
  // const onClick=(id)=>{
  // setTimeout(() => {
  //     navigate("main")
  // }, 100);
  // }
  useEffect(() => {
    Axios.get(
      "https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/Contakt"
    )
      .then((res) => {
        console.log("Getting from ::::", res.data);
        setDate(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  const postData = (e) => {
    if (
      name === " " ||
      surname === "" ||
      email === "" ||
      text === "" ||
      tele === ""
    ) {
      alert("qatorlarda biri to'liq emas ");
    } else {
      e.preventDefault();
      Axios.post(
        "https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/Contakt",
        {
          name,
          surname,

          email,
          text,
          tele,
        },
        setName(""),
        setSurname(""),
        setEmail(""),
        setTele(""),
        setText("")
      )
        .then((res) => console.log("Posting data", res))
        .catch((err) => console.log(err));
      alert(" qabul qilndi");
    }
  };
  return (
    
    <div>
      <Nav/>
      <Container>
        <Row>
          <Col>
            <div style={{ position: "relative", overflow: "hidden" }}>
              <a
                href="https://yandex.uz/maps/10335/tashkent/?utm_medium=mapframe&utm_source=maps"
                style={{
                  color: "#eee",
                  fontSize: "12px",
                  position: "absolute",
                  top: "0px",
                }}
              >
                Toshkent
              </a>
              <a
                href="https://yandex.uz/maps/10335/tashkent/house/YkAYdAFjTEwEQFprfX52eXxqYQ==/?ll=69.263238%2C41.277953&utm_medium=mapframe&utm_source=maps&z=18.68"
                style={{
                  color: "#eee",
                  fontSize: "12px",
                  position: "absolute",
                  top: "14px",
                }}
              >
                Yandex Xarita
              </a>
              <iframe
                src="https://yandex.uz/map-widget/v1/-/CCUNVScuXD"
                width="1256"
                height="350"
                frameborder="1"
                allowfullscreen="true"
                style={{ position: "relative" }}
              ></iframe>
            </div>
            {/* <div className="s-footer-description"><iframe src="https://https://www.google.com/maps/place/%D0%9D%D0%B0%D1%80%D0%B0%D1%89%D0%B8%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5+%D0%B2%D0%BE%D0%BB%D0%BE%D1%81+%D0%B2+%D0%A2%D0%B0%D1%88%D0%BA%D0%B5%D0%BD%D1%82%D0%B5+%7C+Sochlar,+soch+Toshkent+-+volosi.uz/@41.277677,69.2635848,18.25z/data=!4m5!3m4!1s0x38ae8b42551e07a5:0x95060d849adcc26a!8m2!3d41.2778542!4d69.2639987.google.com/maps/@41.2780882,69.2641902,16z" 
    frameborder="0" allowfullscreen="allowfullscreen" 
    style={{border: 'o px',width:"100vh",height:'250px',marginTop:'50px',marginBottom:'50px'}}></iframe> </div>  */}
          </Col>

          <Col style={{ height: "50vh" }}>
            {" "}
            <form>
              <div class="input-box">
                <input
                  type="text"
                  placeholder="Enter your name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div class="input-box">
                <input
                  type="text"
                  placeholder="Enter your surName"
                  required
                  value={surname}
                  onChange={(e) => setSurname(e.target.value)}
                />
              </div>
              <div class="input-box">
                <input
                  type="email"
                  placeholder="Enter your email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>{" "}
              <div class="input-box">
                <input
                  type="number"
                  placeholder="Enter your phone number"
                  value={tele}
                  onChange={(e) => setTele(e.target.value)}
                />
              </div>
              <div class="input-box">
                <textarea
                  style={{ width: "100%", resize: "none" }}
                  rows="4"
                  cols="50"
                  type="text"
                  placeholder="Enter your text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                ></textarea>
              </div>
              <div class="input-box button">
                <input type="Submit" value="Add" onClick={postData} />
              </div>
              <div class="text">
                {/* <h3>Already have an account? <a href="#">Login now</a></h3> */}
              </div>
            </form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}
