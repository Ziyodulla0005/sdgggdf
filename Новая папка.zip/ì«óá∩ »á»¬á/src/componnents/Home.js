import React from 'react'
import { Card, Col, Row,Button, Container} from 'react-bootstrap'
import Tests from './Tests.json'
import Nav from "../nav/Nav";
export default function Home() {
  return (
<div><Nav/>
  <Container>
   <Row>
     {Tests.map((post)=>{
       return(
        <Col> 
          <Card  style={{marginTop:'10px'}}>
            <Card.Img variant="top" src={post.img} style={{width:'100%',height:'200px'}} />
              <Card.Body>
                <Card.Title>{post.name}</Card.Title>
                  <Card.Text>
                 Some quick example text to 
                  </Card.Text>
                  <Button >Go somewhere</Button>
               </Card.Body>
         </Card>
        </Col>
         )
})}
   </Row>
  </Container>
</div>
 


  )
}



